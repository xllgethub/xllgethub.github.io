---
title: 了解蚕蛹
date: 2019-01-11 23:54:09
type: "了解蚕蛹"
avatar: images/touxiang.jpg
---
## 蚕蛹的大小

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;蚕茧的大小和蚕蛹有关，一般来说公的蚕宝宝，它的茧和蛹会比较小。
>![蚕蛹的大小](images/蚕蛹的大小.png)


## **蛹的样子**

- 蚕蛹的正面：蚕蛹的正面身体一样是一节一节的；
>![蚕蛹的正面](images/蛹正.png)

- 蚕蛹的侧面：蚕蛹的侧面也有一个一个的气孔；
>![蚕蛹的侧面](images/蛹侧.png)

- 蚕蛹的腹部面：蚕蛹的腹部面，可以隐约看见翅膀的纹路和触须及三对足。
>![蚕蛹的腹部面](images/蛹腹部.png)


## 蚕在蚕蛹中的变化

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;一般可能认为认为蚕正在蚕蛹中休息，其实蛹的身体里正在发生身体结构的大变化，一方面破坏幼虫时期的身体，一方面又要创造蚕蛾的身体。奇妙的是，它们是同一时间进行的。
>![蚕在蚕蛹中的变化](images/蚕在蚕蛹中的变化.png)


## **蚕蛹不一定能变成蚕蛾**

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;蚕蛹变成蚕蛾后会褪下皮，而体质不良的蚕蛹无法蜕皮变成蚕蛾，全身发黑死在茧里。
>![蚕蛹不一定能变成蚕蛾](images/蚕蛹不一定能变成蚕蛾.png)

[课程视频资源链接]（http://video.tudou.com/v/XMjcxNjgzNzkxNg==.html)
[课程课件资源链接]（https://pan.baidu.com/s/18iaA6a3BU7Iqq8IrFV-stA）
跳转到[首页](..\)